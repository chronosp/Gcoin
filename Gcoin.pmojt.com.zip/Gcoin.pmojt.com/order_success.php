<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <style>
        body{
            height: 100%;
            background-image: url("img/4263932.jpg");
            min-height: 620px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
        }
        
  .block{
    width:700px;
    height:500px;
    margin-top:40px;
    border:1px solid green;
    background-image:url("admin/img/minecraft-video-games-pixels-wallpaper-preview.jpg");
    background-repeat:no-repeat;
    background-size:cover;
    border-radius:30px;
    opacity:0.3;
  }
  
  a{
    text-decoration:none;
  }
  h1{
    color:black;
    margin-top:80px;
  }
  h2{
    color:black;
    margin-top:150px;
  }
    </style>
</head>
<body>
  <br>
      
    <center>
      
      <div class="block">
        <h1>Your Order has successful!</h1>
        <a href="products.php"><h2>--Click here to go back--</h2></a>
      </div>
      
    </center>  
</body>
</html>